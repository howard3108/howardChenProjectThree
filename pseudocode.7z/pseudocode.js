// MVP get the game ready with no animation, scoring, start button with instructions
// stretch show timer(countdown), game over. display player name, smooth animation


// 1 Have a placeholder for score
// 2 Create a trigger instruction pop out on start button click
  // 2a Give instruction with a button
// 3 Instruction button trigger start of game on button click
// 4 Trigger start game function
// 5 Write function to allow mole to randomize and pop out math.random in an array after certain secs if no moles are hit choose new array of moles
// 6 have a event listening function with click on click image hides with the score goes up